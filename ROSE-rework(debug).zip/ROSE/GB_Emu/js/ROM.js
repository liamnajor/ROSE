var e = BigInt(localStorage.getItem('ROM'), 16)
var encoded = window.btoa(e)
B64Load(encoded)