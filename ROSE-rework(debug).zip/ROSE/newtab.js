var n = 1
var newtab = function(src, inp){
	var newScript = document.createElement('iframe');
	newScript.id = "tab"+n+""
	newScript.src = src
	if (n === 1){
		newScript.width = "960"
		newScript.height = "640"
	} else {
		newScript.width = "0"
		newScript.height = "0"
	}
	var scene = document.getElementById('tab')	
	scene.appendChild(newScript);
	var input = document.createElement('input');
	input.id = ""+n+""
	input.type = "button"
	input.value = "show/hide "+inp+""
	var div = document.getElementById('head')
	div.appendChild(input);
	var newScript = document.createElement('script');
	newScript.innerHTML = "var tab"+n+" = document.getElementById('tab"+n+"'); var button = document.getElementById('"+n+"'); button.onclick = function(){if (tab"+n+".width === '0' && tab"+n+".height === '0'){tab"+n+".width = 960; tab"+n+".height = 640} else {tab"+n+".width = 0; tab"+n+".height = 0}}"
	var scene = document.getElementById('tab')
	scene.appendChild(newScript);
	n += 1
}
var id1 = document.getElementById('1').innerHTML
document.getElementById('1').onclick = function(){
    if(document.getElementById('1').innerHTML === id1)     {
        newtab("editor-home.html", "main")
    }
}